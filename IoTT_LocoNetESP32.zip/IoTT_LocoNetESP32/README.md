# Esp32 LocoNet

Implementation of the LocoNet Interface for ESP32

Bit-level transmit and receipt of LocoNet messages including network access and collision detection


